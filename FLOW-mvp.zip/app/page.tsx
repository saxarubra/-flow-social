import { FlowFeed } from "@/components/flow-feed";

export default function Home() {
  return <main><FlowFeed /></main>;
}
