export type FlowVideo = {
  id: string;
  youtubeId: string;
  title: string;
  creator: string;
  category: string;
  subcategory: string;
  tags: string[];
  relatedTopics: string[];
  description: string;
  sourceUrl: string;
};

// Official YouTube embeds only. Availability is checked by the embedded player at runtime.
export const catalog: FlowVideo[] = [
  {
    id: "neural-networks", youtubeId: "aircAruvnKk", title: "But what is a neural network?", creator: "3Blue1Brown",
    category: "Intelligenza artificiale", subcategory: "Reti neurali", tags: ["ai", "machine-learning", "neural-network", "matematica"],
    relatedTopics: ["gradient-descent", "deep-learning", "robotica"], description: "Il punto di partenza: le reti che fanno apprendere le macchine.", sourceUrl: "https://www.youtube.com/watch?v=aircAruvnKk"
  },
  {
    id: "gradient-descent", youtubeId: "IHZwWFHWa-w", title: "Gradient descent, how neural networks learn", creator: "3Blue1Brown",
    category: "Intelligenza artificiale", subcategory: "Apprendimento", tags: ["ai", "machine-learning", "gradient-descent", "neural-network"],
    relatedTopics: ["backpropagation", "deep-learning", "matematica"], description: "Dalla rete al modo in cui migliora a ogni tentativo.", sourceUrl: "https://www.youtube.com/watch?v=IHZwWFHWa-w"
  },
  {
    id: "backpropagation", youtubeId: "Ilg3gGewQ5U", title: "Backpropagation, intuitively", creator: "3Blue1Brown",
    category: "Intelligenza artificiale", subcategory: "Deep learning", tags: ["ai", "machine-learning", "backpropagation", "neural-network"],
    relatedTopics: ["robotica", "deep-learning", "gradient-descent"], description: "Il collegamento successivo: come si correggono gli errori.", sourceUrl: "https://www.youtube.com/watch?v=Ilg3gGewQ5U"
  },
  {
    id: "atlas", youtubeId: "tF4DML7FIWk", title: "Atlas | Partners in Parkour", creator: "Boston Dynamics",
    category: "Robotica", subcategory: "Robot umanoidi", tags: ["robotica", "humanoid", "motori", "movimento"],
    relatedTopics: ["autonomous-systems", "engineering", "ai"], description: "Una deviazione coerente: dall'apprendimento al movimento intelligente.", sourceUrl: "https://www.youtube.com/watch?v=tF4DML7FIWk"
  },
  {
    id: "learning", youtubeId: "5MgBikgcWnY", title: "The first 20 hours — how to learn anything", creator: "TEDx Talks",
    category: "Intelligenza artificiale", subcategory: "Apprendimento", tags: ["ai", "machine-learning", "learning", "prototyping"],
    relatedTopics: ["engineering", "robotica", "deep-learning"], description: "Il percorso torna alle persone: come impariamo e costruiamo.", sourceUrl: "https://www.youtube.com/watch?v=5MgBikgcWnY"
  }
];
