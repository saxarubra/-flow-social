import { catalog, type FlowVideo } from "./catalog";

const overlap = (a: string[], b: string[]) => a.filter((value) => b.includes(value)).length;

/** A transparent, no-cost graph walk. Same input/history always returns the same next item. */
export function nextForPath(current: FlowVideo, seen: string[], nudge = false): FlowVideo | undefined {
  const candidates = catalog.filter((video) => !seen.includes(video.id) && video.id !== current.id);
  return candidates.sort((a, b) => score(b, current, nudge) - score(a, current, nudge) || a.id.localeCompare(b.id))[0];
}

function score(candidate: FlowVideo, current: FlowVideo, nudge: boolean) {
  const direct = overlap(candidate.tags, current.tags) * 10;
  const connection = overlap(candidate.tags, current.relatedTopics) * 14;
  const topicLink = overlap(candidate.relatedTopics, current.tags) * 7;
  const sameCategory = candidate.category === current.category ? 3 : 0;
  // A nudge retains relevance but invites an adjacent branch rather than the closest duplicate.
  const variety = nudge && candidate.subcategory !== current.subcategory ? 8 : 0;
  return direct + connection + topicLink + sameCategory + variety;
}
