# FLOW

MVP mobile-first di un social a percorso continuo. Il feed usa un grafo semantico deterministico: ogni passaggio privilegia tag e argomenti collegati al video appena visto e all'affinità del percorso, evitando ripetizioni.

## Avvio

```bash
npm install
npm run dev
```

## Deploy da iPhone

1. Crea un repository GitHub vuoto chiamato `flow-social` dall'app o dal sito GitHub.
2. Carica questi file con Codex Cloud (o collega questa cartella a GitHub).
3. In Vercel, **Add New → Project**, importa `flow-social` e premi **Deploy**. Vercel rileva automaticamente Next.js.

Nessuna chiave o API a pagamento è necessaria per questa MVP. Le fonti sono iframe ufficiali YouTube: l'app non scarica né estrae video. I cinque ID del catalogo sono stati controllati tramite l'endpoint oEmbed di YouTube il 29 ottobre 2026; il player resta l'autorità finale sull'incorporabilità e l'app conserva sempre il link "Apri la fonte su YouTube".

## Evoluzione

Il catalogo e il motore sono separati in `lib/`. In seguito è possibile sostituire il catalogo locale con Supabase e aggiungere profili, commenti e ranking personalizzato.
