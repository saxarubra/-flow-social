"use client";

import { BookmarkIcon, ChatBubbleOvalLeftEllipsisIcon, HeartIcon, SparklesIcon, SpeakerXMarkIcon } from "@heroicons/react/24/solid";
import { useEffect, useMemo, useRef, useState } from "react";
import { catalog, type FlowVideo } from "@/lib/catalog";
import { nextForPath } from "@/lib/recommendation";

const INITIAL = catalog[0];

export function FlowFeed() {
  const [items, setItems] = useState<FlowVideo[]>([INITIAL]);
  const [active, setActive] = useState(0);
  const [liked, setLiked] = useState<Set<string>>(new Set());
  const [saved, setSaved] = useState<Set<string>>(new Set());
  const [nudge, setNudge] = useState(false);
  const root = useRef<HTMLDivElement>(null);

  const seen = useMemo(() => items.map((item) => item.id), [items]);
  const addNext = (useNudge = false) => {
    const current = items[items.length - 1];
    const next = nextForPath(current, seen, useNudge);
    if (next) setItems((existing) => [...existing, next]);
  };

  useEffect(() => { addNext(false); }, []); // deterministic initial bridge
  useEffect(() => {
    const node = root.current;
    if (!node) return;
    const observer = new IntersectionObserver((entries) => {
      const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (!visible) return;
      const index = Number((visible.target as HTMLElement).dataset.index);
      setActive(index);
      if (index >= items.length - 2) addNext(nudge);
    }, { root: node, threshold: 0.7 });
    node.querySelectorAll<HTMLElement>("[data-index]").forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, [items, nudge, seen]);

  const toggle = (setter: React.Dispatch<React.SetStateAction<Set<string>>>, id: string) => {
    setter((existing) => { const updated = new Set(existing); updated.has(id) ? updated.delete(id) : updated.add(id); return updated; });
  };

  return <div ref={root} className="h-[100dvh] snap-y snap-mandatory overflow-y-auto bg-black text-white" aria-label="Feed FLOW">
    <header className="pointer-events-none fixed inset-x-0 top-0 z-20 flex items-center justify-between px-5 pt-[max(1rem,env(safe-area-inset-top))]">
      <span className="text-lg font-black tracking-[-0.08em]">FLOW<span className="text-lime-300">.</span></span>
      <span className="rounded-full border border-white/15 bg-black/35 px-3 py-1 text-[10px] font-medium uppercase tracking-[0.14em] backdrop-blur">AI journey</span>
    </header>
    {items.map((video, index) => <VideoCard key={`${video.id}-${index}`} index={index} video={video} active={active === index} liked={liked.has(video.id)} saved={saved.has(video.id)} onLike={() => toggle(setLiked, video.id)} onSave={() => toggle(setSaved, video.id)} onNudge={() => setNudge((value) => !value)} nudge={nudge} />)}
  </div>;
}

function VideoCard({ video, index, active, liked, saved, onLike, onSave, onNudge, nudge }: { video: FlowVideo; index: number; active: boolean; liked: boolean; saved: boolean; onLike: () => void; onSave: () => void; onNudge: () => void; nudge: boolean }) {
  const [blocked, setBlocked] = useState(false);
  return <article data-index={index} className="relative h-[100dvh] snap-start overflow-hidden bg-zinc-950" aria-label={video.title}>
    <div className="absolute inset-0 scale-[1.35] bg-gradient-to-b from-zinc-800 via-black to-black" />
    {active && !blocked && <iframe className="absolute inset-0 h-full w-full scale-[1.34]" src={`https://www.youtube-nocookie.com/embed/${video.youtubeId}?autoplay=1&mute=1&playsinline=1&rel=0&modestbranding=1`} title={video.title} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen onError={() => setBlocked(true)} />}
    <div className="absolute inset-0 bg-gradient-to-b from-black/35 via-transparent to-black/90" />
    {blocked && <a href={video.sourceUrl} target="_blank" rel="noreferrer" className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-3 bg-zinc-900 px-12 text-center"><SpeakerXMarkIcon className="h-10 w-10 text-lime-300" /><span className="text-sm font-semibold">Questo video non è incorporabile qui.</span><span className="rounded-full bg-white px-4 py-2 text-xs font-bold text-black">Apri su YouTube</span></a>}
    <div className="absolute inset-x-0 bottom-0 z-10 flex items-end gap-4 px-5 pb-[max(1.5rem,env(safe-area-inset-bottom))] pt-24">
      <div className="min-w-0 flex-1"><p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.16em] text-lime-300">{video.category} · {video.subcategory}</p><h1 className="max-w-[18rem] text-xl font-bold leading-tight">{video.title}</h1><p className="mt-2 text-sm text-white/70">{video.creator} · {video.description}</p><a className="mt-3 inline-block text-[11px] text-white/55 underline decoration-white/30 underline-offset-4" href={video.sourceUrl} target="_blank" rel="noreferrer">Apri la fonte su YouTube</a><p className="mt-2 truncate text-[11px] text-white/45">Prossimo: collegato per tag e argomenti</p></div>
      <div className="flex w-12 flex-col items-center gap-4 pb-1"><Action active={liked} icon={<HeartIcon />} label="Mi piace" onClick={onLike} /><Action active={saved} icon={<BookmarkIcon />} label="Salva" onClick={onSave} /><Action icon={<ChatBubbleOvalLeftEllipsisIcon />} label="Commenti prossimamente" onClick={() => undefined} /><Action active={nudge} icon={<SparklesIcon />} label="Devia leggermente" onClick={onNudge} /></div>
    </div>
  </article>;
}

function Action({ icon, label, onClick, active = false }: { icon: React.ReactNode; label: string; onClick: () => void; active?: boolean }) {
  return <button type="button" aria-label={label} title={label} onClick={onClick} className={`grid h-11 w-11 place-items-center rounded-full border transition active:scale-90 ${active ? "border-lime-300 bg-lime-300 text-black" : "border-white/20 bg-black/35 text-white backdrop-blur"}`}><span className="h-5 w-5">{icon}</span></button>;
}
